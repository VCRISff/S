import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Award, Users } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'linear-gradient(rgba(47, 79, 79, 0.4), rgba(135, 169, 107, 0.3)), url(https://images.pexels.com/photos/3757941/pexels-photo-3757941.jpeg)'
        }}
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-fade-in">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-playfair font-bold text-white mb-6">
            Discover Your
            <span className="block text-spa-gold">Inner Peace</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-spa-cream mb-8 max-w-3xl mx-auto font-inter font-light">
            Experience the ultimate in luxury spa treatments designed to rejuvenate your body, mind, and spirit
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link
              to="/booking"
              className="bg-spa-gold text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spa-earth transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:-translate-y-1"
            >
              Book Your Experience
            </Link>
            <Link
              to="/services"
              className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-spa-deep transition-all duration-300"
            >
              View Services
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center text-white">
              <Sparkles className="w-8 h-8 text-spa-gold mb-3" />
              <h3 className="text-lg font-semibold mb-2">Premium Treatments</h3>
              <p className="text-spa-cream text-sm">Expertly crafted experiences using the finest natural ingredients</p>
            </div>
            
            <div className="flex flex-col items-center text-white">
              <Award className="w-8 h-8 text-spa-gold mb-3" />
              <h3 className="text-lg font-semibold mb-2">Award-Winning Spa</h3>
              <p className="text-spa-cream text-sm">Recognized for excellence in luxury wellness and customer service</p>
            </div>
            
            <div className="flex flex-col items-center text-white">
              <Users className="w-8 h-8 text-spa-gold mb-3" />
              <h3 className="text-lg font-semibold mb-2">Expert Therapists</h3>
              <p className="text-spa-cream text-sm">Certified professionals dedicated to your wellness journey</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;