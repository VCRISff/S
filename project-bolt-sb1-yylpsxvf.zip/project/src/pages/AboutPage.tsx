import React from 'react';
import { Award, Users, Heart, Leaf, Star, Clock } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-spa-cream pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            About Healing Days
          </h1>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            Your sanctuary for wellness, relaxation, and rejuvenation since 2010
          </p>
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          <div className="space-y-6">
            <h2 className="text-3xl font-playfair font-bold text-spa-deep">Our Story</h2>
            <p className="text-spa-stone font-inter leading-relaxed">
              Founded in 2010 with a vision to create a haven of tranquility in the heart of the city, 
              Healing Days has grown to become the premier destination for luxury wellness experiences. 
              Our journey began with a simple belief: everyone deserves a space to heal, rejuvenate, 
              and reconnect with their inner peace.
            </p>
            <p className="text-spa-stone font-inter leading-relaxed">
              Over the years, we've carefully curated a team of world-class therapists and wellness 
              experts who share our passion for holistic healing. Every treatment, every detail, 
              and every moment at Healing Days is designed to transport you to a state of complete 
              relaxation and renewal.
            </p>
            <p className="text-spa-stone font-inter leading-relaxed">
              Today, we're proud to be recognized as an award-winning spa, but our true measure 
              of success lies in the countless guests who leave feeling refreshed, renewed, and 
              ready to embrace life with renewed energy.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3985327/pexels-photo-3985327.jpeg"
              alt="Spa interior"
              className="w-full h-96 object-cover rounded-2xl shadow-xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-spa-deep/20 to-transparent rounded-2xl"></div>
          </div>
        </div>

        {/* Values Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-12">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Compassionate Care</h3>
              <p className="text-spa-stone text-sm">
                Every guest is treated with genuine care and attention to their unique needs
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Natural Wellness</h3>
              <p className="text-spa-stone text-sm">
                We use only the finest natural and organic products in all our treatments
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-earth rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Excellence</h3>
              <p className="text-spa-stone text-sm">
                We strive for perfection in every detail of your spa experience
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-stone rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Timeless Tradition</h3>
              <p className="text-spa-stone text-sm">
                Honoring ancient wellness practices while embracing modern innovations
              </p>
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-12">
            Meet Our Expert Team
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Dr. Sarah Chen",
                role: "Spa Director & Wellness Expert",
                image: "https://images.pexels.com/photos/8134842/pexels-photo-8134842.jpeg",
                bio: "15+ years in holistic wellness"
              },
              {
                name: "Marcus Rodriguez",
                role: "Lead Massage Therapist",
                image: "https://images.pexels.com/photos/8134844/pexels-photo-8134844.jpeg",
                bio: "Certified in 12 massage modalities"
              },
              {
                name: "Elena Petrov",
                role: "Senior Esthetician",
                image: "https://images.pexels.com/photos/8134841/pexels-photo-8134841.jpeg",
                bio: "Advanced skincare specialist"
              },
              {
                name: "James Thompson",
                role: "Hydrotherapy Specialist",
                image: "https://images.pexels.com/photos/8134843/pexels-photo-8134843.jpeg",
                bio: "Expert in water-based healing"
              }
            ].map((member, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-spa-deep mb-1">{member.name}</h3>
                  <p className="text-spa-gold text-sm font-semibold mb-2">{member.role}</p>
                  <p className="text-spa-stone text-xs">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Awards Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-8">
            Awards & Recognition
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <Award className="w-12 h-12 text-spa-gold mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Best Luxury Spa 2023</h3>
              <p className="text-spa-stone text-sm">Wellness & Beauty Awards</p>
            </div>
            <div className="text-center">
              <Users className="w-12 h-12 text-spa-gold mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Customer Choice Award</h3>
              <p className="text-spa-stone text-sm">Spa Industry Excellence</p>
            </div>
            <div className="text-center">
              <Star className="w-12 h-12 text-spa-gold mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-spa-deep mb-2">5-Star Rating</h3>
              <p className="text-spa-stone text-sm">Consistently rated by guests</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;