import React, { useState } from 'react';
import { Calendar, Clock, User, Star, MapPin, Phone, Mail, ArrowLeft, Check } from 'lucide-react';
import { format } from 'date-fns';
import { BookingData } from '../../types';

interface BookingConfirmationProps {
  bookingData: BookingData;
  onBack: () => void;
  onConfirm: () => void;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bookingData,
  onBack,
  onConfirm,
}) => {
  const [contactInfo, setContactInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  });
  const [isConfirmed, setIsConfirmed] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setContactInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleConfirmBooking = () => {
    setIsConfirmed(true);
    setTimeout(() => {
      onConfirm();
    }, 2000);
  };

  const isFormValid = contactInfo.firstName && contactInfo.lastName && 
                     contactInfo.email && contactInfo.phone;

  if (isConfirmed) {
    return (
      <div className="p-6 text-center">
        <div className="mb-6">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-playfair font-bold text-spa-deep mb-2">
            Booking Confirmed!
          </h3>
          <p className="text-spa-stone">
            Your spa experience has been successfully booked. We've sent a confirmation email to {contactInfo.email}.
          </p>
        </div>
        
        <div className="bg-spa-cream rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-spa-deep mb-2">Booking Reference</h4>
          <p className="text-lg font-mono font-bold text-spa-gold">
            HD-{Date.now().toString().slice(-6)}
          </p>
        </div>
        
        <p className="text-sm text-spa-stone">
          Please arrive 15 minutes early for your appointment. We look forward to welcoming you to Healing Days!
        </p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Confirm Your Booking
        </h3>
        <p className="text-spa-stone text-sm">
          Please review your booking details and provide your contact information
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Booking Summary */}
        <div>
          <h4 className="text-lg font-semibold text-spa-deep mb-4">Booking Summary</h4>
          
          <div className="space-y-4">
            {/* Date & Time */}
            <div className="flex items-start space-x-3">
              <Calendar className="w-5 h-5 text-spa-sage mt-0.5" />
              <div>
                <p className="font-semibold text-spa-deep">
                  {bookingData.selectedDate && format(bookingData.selectedDate, 'EEEE, MMMM d, yyyy')}
                </p>
                <p className="text-sm text-spa-stone">{bookingData.selectedTime}</p>
              </div>
            </div>

            {/* Duration */}
            <div className="flex items-start space-x-3">
              <Clock className="w-5 h-5 text-spa-sage mt-0.5" />
              <div>
                <p className="font-semibold text-spa-deep">
                  {Math.floor(bookingData.totalDuration / 60)}h {bookingData.totalDuration % 60}m
                </p>
                <p className="text-sm text-spa-stone">Total duration</p>
              </div>
            </div>

            {/* Therapist */}
            {bookingData.selectedTherapist && (
              <div className="flex items-start space-x-3">
                <User className="w-5 h-5 text-spa-sage mt-0.5" />
                <div>
                  <p className="font-semibold text-spa-deep">
                    {bookingData.selectedTherapist.name}
                  </p>
                  <div className="flex items-center text-sm text-spa-stone">
                    <Star className="w-3 h-3 text-spa-gold fill-spa-gold mr-1" />
                    {bookingData.selectedTherapist.rating} • {bookingData.selectedTherapist.experience} years
                  </div>
                </div>
              </div>
            )}

            {/* Services */}
            <div>
              <h5 className="font-semibold text-spa-deep mb-2">Services:</h5>
              <div className="space-y-1">
                {bookingData.services.map((service) => (
                  <div key={service.id} className="flex justify-between text-sm">
                    <span>{service.name}</span>
                    <span>${service.price}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Add-ons */}
            {bookingData.addOns.length > 0 && (
              <div>
                <h5 className="font-semibold text-spa-deep mb-2">Add-ons:</h5>
                <div className="space-y-1">
                  {bookingData.addOns.map((addOn) => (
                    <div key={addOn.id} className="flex justify-between text-sm">
                      <span>{addOn.name}</span>
                      <span>+${addOn.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Special Requests */}
            {bookingData.specialRequests && (
              <div>
                <h5 className="font-semibold text-spa-deep mb-2">Special Requests:</h5>
                <p className="text-sm text-spa-stone bg-gray-50 p-3 rounded">
                  {bookingData.specialRequests}
                </p>
              </div>
            )}

            {/* Total */}
            <div className="border-t pt-4">
              <div className="flex justify-between text-lg font-bold text-spa-deep">
                <span>Total:</span>
                <span>${bookingData.totalPrice}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div>
          <h4 className="text-lg font-semibold text-spa-deep mb-4">Contact Information</h4>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  First Name *
                </label>
                <input
                  type="text"
                  value={contactInfo.firstName}
                  onChange={(e) => handleInputChange('firstName', e.target.value)}
                  className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  Last Name *
                </label>
                <input
                  type="text"
                  value={contactInfo.lastName}
                  onChange={(e) => handleInputChange('lastName', e.target.value)}
                  className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-spa-deep mb-2">
                Email Address *
              </label>
              <input
                type="email"
                value={contactInfo.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-spa-deep mb-2">
                Phone Number *
              </label>
              <input
                type="tel"
                value={contactInfo.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Spa Information */}
          <div className="mt-8 bg-spa-cream rounded-lg p-4">
            <h5 className="font-semibold text-spa-deep mb-3">Spa Information</h5>
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <MapPin className="w-4 h-4 text-spa-sage mr-2" />
                <span>123 Wellness Street, Spa District, SD 12345</span>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 text-spa-sage mr-2" />
                <span>(555) 123-4567</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-4 h-4 text-spa-sage mr-2" />
                <span>bookings@healingdays.com</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Add-ons
        </button>
        
        <button
          onClick={handleConfirmBooking}
          disabled={!isFormValid}
          className={`px-8 py-3 rounded-full font-semibold ${
            isFormValid
              ? 'bg-spa-gold text-white hover:bg-spa-earth'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          } transition-colors`}
        >
          Confirm Booking
        </button>
      </div>
    </div>
  );
};

export default BookingConfirmation;