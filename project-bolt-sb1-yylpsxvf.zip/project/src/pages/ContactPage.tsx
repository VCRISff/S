import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    alert('Thank you for your message! We\'ll get back to you soon.');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-spa-cream pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            Contact Us
          </h1>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            We'd love to hear from you. Get in touch with our team for bookings, questions, or just to say hello.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-playfair font-bold text-spa-deep mb-6">
                Get in Touch
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-spa-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-spa-deep mb-1">Visit Us</h3>
                    <p className="text-spa-stone">
                      123 Wellness Street<br />
                      Spa District, SD 12345<br />
                      United States
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-spa-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-spa-deep mb-1">Call Us</h3>
                    <p className="text-spa-stone">
                      Main: (555) 123-4567<br />
                      Bookings: (555) 123-4568<br />
                      Emergency: (555) 123-4569
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-spa-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-spa-deep mb-1">Email Us</h3>
                    <p className="text-spa-stone">
                      General: info@healingdays.com<br />
                      Bookings: bookings@healingdays.com<br />
                      Support: support@healingdays.com
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 text-spa-gold mt-1" />
                  <div>
                    <h3 className="font-semibold text-spa-deep mb-1">Hours</h3>
                    <p className="text-spa-stone">
                      Monday - Friday: 9:00 AM - 8:00 PM<br />
                      Saturday - Sunday: 8:00 AM - 9:00 PM<br />
                      Holidays: 10:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-playfair font-bold text-spa-deep mb-4">
                Find Us
              </h3>
              <div className="bg-spa-cream rounded-lg h-64 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-spa-gold mx-auto mb-2" />
                  <p className="text-spa-stone">Interactive map would be here</p>
                  <p className="text-spa-stone text-sm">123 Wellness Street, Spa District</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-playfair font-bold text-spa-deep mb-6">
              Send us a Message
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Subject *
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => handleInputChange('subject', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    required
                  >
                    <option value="">Select a subject</option>
                    <option value="booking">Booking Inquiry</option>
                    <option value="services">Services Information</option>
                    <option value="packages">Package Details</option>
                    <option value="gift-cards">Gift Cards</option>
                    <option value="membership">Membership</option>
                    <option value="feedback">Feedback</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  Message *
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  rows={6}
                  className="w-full p-3 border border-gray-200 rounded-lg resize-none focus:border-spa-sage focus:outline-none"
                  placeholder="Tell us how we can help you..."
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-spa-gold text-white py-3 rounded-full font-semibold hover:bg-spa-earth transition-colors shadow-lg hover:shadow-xl flex items-center justify-center"
              >
                <Send className="w-5 h-5 mr-2" />
                Send Message
              </button>
            </form>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-20 bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-playfair font-bold text-spa-deep text-center mb-8">
            Frequently Asked Questions
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-spa-deep mb-2">How far in advance should I book?</h3>
              <p className="text-spa-stone text-sm mb-4">
                We recommend booking 1-2 weeks in advance, especially for weekends and popular treatments.
              </p>
              
              <h3 className="font-semibold text-spa-deep mb-2">What should I arrive early?</h3>
              <p className="text-spa-stone text-sm mb-4">
                Please arrive 15 minutes early to complete check-in and enjoy our relaxation area.
              </p>
              
              <h3 className="font-semibold text-spa-deep mb-2">Do you offer couple's treatments?</h3>
              <p className="text-spa-stone text-sm">
                Yes! We have dedicated couple's suites and special packages for romantic experiences.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-spa-deep mb-2">What is your cancellation policy?</h3>
              <p className="text-spa-stone text-sm mb-4">
                Cancellations must be made 24 hours in advance to avoid charges.
              </p>
              
              <h3 className="font-semibold text-spa-deep mb-2">Do you offer gift cards?</h3>
              <p className="text-spa-stone text-sm mb-4">
                Yes! Gift cards are available for any amount and make perfect gifts for loved ones.
              </p>
              
              <h3 className="font-semibold text-spa-deep mb-2">Is parking available?</h3>
              <p className="text-spa-stone text-sm">
                We offer complimentary valet parking for all spa guests.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;