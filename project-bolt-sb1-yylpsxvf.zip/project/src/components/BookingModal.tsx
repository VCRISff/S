import React, { useState } from 'react';
import { X } from 'lucide-react';
import { BookingData } from '../types';
import ServiceSelection from './booking/ServiceSelection';
import PackageSelection from './booking/PackageSelection';
import DateTimeSelection from './booking/DateTimeSelection';
import TherapistSelection from './booking/TherapistSelection';
import AddOnsSelection from './booking/AddOnsSelection';
import BookingConfirmation from './booking/BookingConfirmation';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type BookingStep = 'service' | 'package' | 'datetime' | 'therapist' | 'addons' | 'confirmation';

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const [currentStep, setCurrentStep] = useState<BookingStep>('service');
  const [bookingData, setBookingData] = useState<BookingData>({
    services: [],
    packages: [],
    selectedDate: null,
    selectedTime: '',
    selectedTherapist: null,
    addOns: [],
    specialRequests: '',
    totalDuration: 0,
    totalPrice: 0,
  });

  const handleClose = () => {
    setCurrentStep('service');
    setBookingData({
      services: [],
      packages: [],
      selectedDate: null,
      selectedTime: '',
      selectedTherapist: null,
      addOns: [],
      specialRequests: '',
      totalDuration: 0,
      totalPrice: 0,
    });
    onClose();
  };

  const steps: { key: BookingStep; title: string }[] = [
    { key: 'service', title: 'Select Services' },
    { key: 'package', title: 'Choose Package' },
    { key: 'datetime', title: 'Date & Time' },
    { key: 'therapist', title: 'Select Therapist' },
    { key: 'addons', title: 'Add-ons' },
    { key: 'confirmation', title: 'Confirmation' },
  ];

  const currentStepIndex = steps.findIndex(step => step.key === currentStep);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-playfair font-bold text-spa-deep">
              Book Your Experience
            </h2>
            <p className="text-spa-stone text-sm mt-1">
              Step {currentStepIndex + 1} of {steps.length}: {steps[currentStepIndex].title}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex mb-6 px-6 pt-4">
          {steps.map((step, index) => (
            <div key={step.key} className="flex-1 flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  index <= currentStepIndex
                    ? 'bg-spa-gold text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
              >
                {index + 1}
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`flex-1 h-0.5 mx-2 ${
                    index < currentStepIndex ? 'bg-spa-gold' : 'bg-gray-200'
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        <div className="overflow-y-auto" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          {currentStep === 'service' && (
            <ServiceSelection
              bookingData={bookingData}
              setBookingData={setBookingData}
              onNext={() => setCurrentStep('package')}
            />
          )}
          {currentStep === 'package' && (
            <PackageSelection
              bookingData={bookingData}
              setBookingData={setBookingData}
              onNext={() => setCurrentStep('datetime')}
              onBack={() => setCurrentStep('service')}
            />
          )}
          {currentStep === 'datetime' && (
            <DateTimeSelection
              bookingData={bookingData}
              setBookingData={setBookingData}
              onNext={() => setCurrentStep('therapist')}
              onBack={() => setCurrentStep('package')}
            />
          )}
          {currentStep === 'therapist' && (
            <TherapistSelection
              bookingData={bookingData}
              setBookingData={setBookingData}
              onNext={() => setCurrentStep('addons')}
              onBack={() => setCurrentStep('datetime')}
            />
          )}
          {currentStep === 'addons' && (
            <AddOnsSelection
              bookingData={bookingData}
              setBookingData={setBookingData}
              onNext={() => setCurrentStep('confirmation')}
              onBack={() => setCurrentStep('therapist')}
            />
          )}
          {currentStep === 'confirmation' && (
            <BookingConfirmation
              bookingData={bookingData}
              onBack={() => setCurrentStep('addons')}
              onConfirm={handleClose}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingModal;