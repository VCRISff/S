import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, MapPin } from 'lucide-react';

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="flex items-center">
            <div className="text-2xl md:text-3xl font-playfair font-bold text-spa-deep">
              Healing Days
            </div>
            <div className="ml-2 text-sm text-spa-sage font-inter">Luxury Spa</div>
          </Link>

          <nav className="hidden md:flex space-x-8">
            <Link 
              to="/" 
              className={`font-inter transition-colors ${
                isActive('/') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/services" 
              className={`font-inter transition-colors ${
                isActive('/services') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
              }`}
            >
              Services
            </Link>
            <Link 
              to="/packages" 
              className={`font-inter transition-colors ${
                isActive('/packages') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
              }`}
            >
              Packages
            </Link>
            <Link 
              to="/about" 
              className={`font-inter transition-colors ${
                isActive('/about') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
              }`}
            >
              About
            </Link>
            <Link 
              to="/contact" 
              className={`font-inter transition-colors ${
                isActive('/contact') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
              }`}
            >
              Contact
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center text-spa-stone text-sm">
              <Phone className="w-4 h-4 mr-1" />
              <span>(555) 123-4567</span>
            </div>
            <Link
              to="/booking"
              className="bg-spa-gold text-white px-6 py-3 rounded-full font-semibold hover:bg-spa-earth transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Book Now
            </Link>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className={`font-inter transition-colors ${
                  isActive('/') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/services" 
                className={`font-inter transition-colors ${
                  isActive('/services') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Services
              </Link>
              <Link 
                to="/packages" 
                className={`font-inter transition-colors ${
                  isActive('/packages') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Packages
              </Link>
              <Link 
                to="/about" 
                className={`font-inter transition-colors ${
                  isActive('/about') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className={`font-inter transition-colors ${
                  isActive('/contact') ? 'text-spa-gold font-semibold' : 'text-spa-deep hover:text-spa-sage'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <div className="flex items-center text-spa-stone text-sm pt-2">
                <Phone className="w-4 h-4 mr-1" />
                <span>(555) 123-4567</span>
              </div>
              <Link
                to="/booking"
                className="bg-spa-gold text-white px-6 py-3 rounded-full font-semibold hover:bg-spa-earth transition-colors w-full text-center"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Book Now
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;