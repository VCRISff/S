import React from 'react';
import { Check, Crown, Star, Gift, Calendar, Percent } from 'lucide-react';

const MembershipPage: React.FC = () => {
  const membershipTiers = [
    {
      name: 'Wellness Explorer',
      price: 49,
      icon: Star,
      color: 'spa-sage',
      popular: false,
      benefits: [
        '10% discount on all services',
        'Priority booking access',
        'Monthly wellness newsletter',
        'Birthday month special offer',
        'Free consultation session'
      ]
    },
    {
      name: 'Serenity Member',
      price: 99,
      icon: Gift,
      color: 'spa-gold',
      popular: true,
      benefits: [
        '15% discount on all services',
        '20% discount on packages',
        'Priority booking access',
        'Complimentary add-on service monthly',
        'Free guest passes (2 per year)',
        'Exclusive member-only events',
        'Extended booking window'
      ]
    },
    {
      name: 'Elite Sanctuary',
      price: 199,
      icon: Crown,
      color: 'spa-earth',
      popular: false,
      benefits: [
        '25% discount on all services',
        '30% discount on packages',
        'Unlimited priority booking',
        'Monthly complimentary treatment',
        'Free guest passes (6 per year)',
        'Personal wellness consultant',
        'VIP lounge access',
        'Exclusive retreat invitations'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-spa-cream pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            Membership Programs
          </h1>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            Join our exclusive membership program and enjoy premium benefits, priority access, and significant savings on all treatments.
          </p>
        </div>

        {/* Membership Tiers */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {membershipTiers.map((tier, index) => {
            const IconComponent = tier.icon;
            return (
              <div
                key={tier.name}
                className={`bg-white rounded-2xl shadow-xl overflow-hidden relative ${
                  tier.popular ? 'border-2 border-spa-gold transform scale-105' : ''
                }`}
              >
                {tier.popular && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="bg-spa-gold text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </div>
                  </div>
                )}
                
                <div className={`bg-${tier.color} text-white p-6 text-center`}>
                  <IconComponent className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-playfair font-bold mb-2">{tier.name}</h3>
                  <div className="text-4xl font-bold mb-2">
                    ${tier.price}
                    <span className="text-lg font-normal">/month</span>
                  </div>
                  <p className="text-sm opacity-90">Billed monthly, cancel anytime</p>
                </div>
                
                <div className="p-6">
                  <ul className="space-y-3 mb-8">
                    {tier.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start space-x-3">
                        <Check className="w-5 h-5 text-spa-sage mt-0.5 flex-shrink-0" />
                        <span className="text-spa-stone text-sm">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <button
                    className={`w-full py-3 rounded-full font-semibold transition-colors ${
                      tier.popular
                        ? 'bg-spa-gold text-white hover:bg-spa-earth'
                        : `bg-${tier.color} text-white hover:bg-spa-deep`
                    }`}
                  >
                    Choose {tier.name}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Membership Benefits Overview */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-20">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-12">
            Why Become a Member?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Percent className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Exclusive Savings</h3>
              <p className="text-spa-stone text-sm">
                Save up to 30% on all services and packages with your membership
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Priority Access</h3>
              <p className="text-spa-stone text-sm">
                Book appointments before non-members and access exclusive time slots
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-earth rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Special Perks</h3>
              <p className="text-spa-stone text-sm">
                Enjoy complimentary services, guest passes, and exclusive events
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-stone rounded-full flex items-center justify-center mx-auto mb-4">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">VIP Treatment</h3>
              <p className="text-spa-stone text-sm">
                Experience personalized service and access to exclusive areas
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-8">
            Membership FAQ
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">How does billing work?</h3>
                <p className="text-spa-stone text-sm">
                  Memberships are billed monthly on the date you sign up. You can cancel anytime with 30 days notice.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">Can I upgrade or downgrade my membership?</h3>
                <p className="text-spa-stone text-sm">
                  Yes! You can change your membership tier at any time. Changes take effect on your next billing cycle.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">Do unused benefits roll over?</h3>
                <p className="text-spa-stone text-sm">
                  Complimentary services and guest passes expire at the end of each membership year but discounts never expire.
                </p>
              </div>
            </div>
            
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">Can I share my membership benefits?</h3>
                <p className="text-spa-stone text-sm">
                  Discounts are for the member only, but you can use guest passes to bring friends and family.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">Is there a contract or commitment?</h3>
                <p className="text-spa-stone text-sm">
                  No long-term contracts required. All memberships are month-to-month with easy cancellation.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-spa-deep mb-2">How do I book as a member?</h3>
                <p className="text-spa-stone text-sm">
                  Members get access to our priority booking system and can book further in advance than non-members.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MembershipPage;