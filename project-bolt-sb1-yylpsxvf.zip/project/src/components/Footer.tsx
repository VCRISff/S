import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-spa-deep text-spa-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <Link to="/" className="text-2xl font-playfair font-bold text-white mb-4 block">
              Healing Days
            </Link>
            <p className="text-spa-cream/80 mb-6">
              Your sanctuary for wellness, relaxation, and rejuvenation. Experience the ultimate in luxury spa treatments.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-spa-gold hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-spa-gold hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-spa-gold hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Services</h3>
            <ul className="space-y-2 text-spa-cream/80">
              <li><Link to="/services" className="hover:text-white transition-colors">Massage Therapy</Link></li>
              <li><Link to="/services" className="hover:text-white transition-colors">Facial Treatments</Link></li>
              <li><Link to="/services" className="hover:text-white transition-colors">Body Treatments</Link></li>
              <li><Link to="/services" className="hover:text-white transition-colors">Hydrotherapy</Link></li>
              <li><Link to="/packages" className="hover:text-white transition-colors">Wellness Packages</Link></li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2 text-spa-cream/80">
              <li><Link to="/booking" className="hover:text-white transition-colors">Book Appointment</Link></li>
              <li><Link to="/gift-cards" className="hover:text-white transition-colors">Gift Cards</Link></li>
              <li><Link to="/membership" className="hover:text-white transition-colors">Membership</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Contact</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-spa-gold mt-0.5" />
                <div className="text-spa-cream/80">
                  <p>123 Wellness Street</p>
                  <p>Spa District, SD 12345</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-spa-gold" />
                <span className="text-spa-cream/80">(555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-spa-gold" />
                <span className="text-spa-cream/80">info@healingdays.com</span>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-white mb-2">Hours</h4>
              <div className="text-spa-cream/80 text-sm space-y-1">
                <p>Monday - Friday: 9:00 AM - 8:00 PM</p>
                <p>Saturday - Sunday: 8:00 AM - 9:00 PM</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-spa-cream/20 mt-12 pt-8 text-center">
          <p className="text-spa-cream/60 text-sm">
            © 2024 Healing Days Luxury Spa. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;