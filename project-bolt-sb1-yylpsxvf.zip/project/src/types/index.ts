export interface Service {
  id: string;
  name: string;
  category: string;
  duration: number;
  price: number;
  description: string;
  benefits: string[];
  image: string;
}

export interface ServicePackage {
  id: string;
  name: string;
  services: string[];
  originalPrice: number;
  packagePrice: number;
  duration: number;
  description: string;
  image: string;
}

export interface Therapist {
  id: string;
  name: string;
  specializations: string[];
  experience: number;
  rating: number;
  image: string;
  bio: string;
}

export interface AddOn {
  id: string;
  name: string;
  price: number;
  duration: number;
  description: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
  therapistId?: string;
}

export interface BookingData {
  services: Service[];
  packages: ServicePackage[];
  selectedDate: Date | null;
  selectedTime: string;
  selectedTherapist: Therapist | null;
  addOns: AddOn[];
  specialRequests: string;
  totalDuration: number;
  totalPrice: number;
}