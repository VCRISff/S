import React from 'react';
import { Plus, Minus, Clock, ArrowLeft } from 'lucide-react';
import { addOns } from '../../data/services';
import { BookingData, AddOn } from '../../types';

interface AddOnsSelectionProps {
  bookingData: BookingData;
  setBookingData: (data: BookingData) => void;
  onNext: () => void;
  onBack: () => void;
}

const AddOnsSelection: React.FC<AddOnsSelectionProps> = ({
  bookingData,
  setBookingData,
  onNext,
  onBack,
}) => {
  const isAddOnSelected = (addOn: AddOn) => {
    return bookingData.addOns.some(a => a.id === addOn.id);
  };

  const toggleAddOn = (addOn: AddOn) => {
    const isSelected = isAddOnSelected(addOn);
    let updatedAddOns: AddOn[];
    
    if (isSelected) {
      updatedAddOns = bookingData.addOns.filter(a => a.id !== addOn.id);
    } else {
      updatedAddOns = [...bookingData.addOns, addOn];
    }

    const addOnsDuration = updatedAddOns.reduce((sum, a) => sum + a.duration, 0);
    const addOnsPrice = updatedAddOns.reduce((sum, a) => sum + a.price, 0);
    
    // Calculate base price from services and packages
    let basePrice = 0;
    let baseDuration = 0;
    
    if (bookingData.packages.length > 0) {
      basePrice = bookingData.packages.reduce((sum, p) => sum + p.packagePrice, 0);
      baseDuration = bookingData.packages.reduce((sum, p) => sum + p.duration, 0);
    } else {
      basePrice = bookingData.services.reduce((sum, s) => sum + s.price, 0);
      baseDuration = bookingData.services.reduce((sum, s) => sum + s.duration, 0);
    }

    setBookingData({
      ...bookingData,
      addOns: updatedAddOns,
      totalDuration: baseDuration + addOnsDuration,
      totalPrice: basePrice + addOnsPrice,
    });
  };

  const handleSpecialRequests = (value: string) => {
    setBookingData({
      ...bookingData,
      specialRequests: value,
    });
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Enhance Your Experience
        </h3>
        <p className="text-spa-stone text-sm">
          Add optional enhancements to make your spa visit even more special
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {addOns.map((addOn) => {
          const selected = isAddOnSelected(addOn);
          
          return (
            <div
              key={addOn.id}
              className={`border rounded-lg p-4 cursor-pointer transition-all ${
                selected
                  ? 'border-spa-gold bg-spa-gold/10'
                  : 'border-gray-200 hover:border-spa-sage'
              }`}
              onClick={() => toggleAddOn(addOn)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-semibold text-spa-deep mb-1">
                    {addOn.name}
                  </h4>
                  <div className="flex items-center gap-3 text-sm text-spa-stone mb-2">
                    {addOn.duration > 0 && (
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        <span>+{addOn.duration} min</span>
                      </div>
                    )}
                    <span className="font-semibold">+${addOn.price}</span>
                  </div>
                  <p className="text-xs text-spa-stone">
                    {addOn.description}
                  </p>
                </div>
                <div className="ml-4">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      selected
                        ? 'bg-spa-gold text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {selected ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mb-8">
        <h4 className="text-lg font-semibold text-spa-deep mb-3">
          Special Requests or Notes
        </h4>
        <textarea
          value={bookingData.specialRequests}
          onChange={(e) => handleSpecialRequests(e.target.value)}
          placeholder="Any special requests, allergies, preferences, or notes for your therapist..."
          className="w-full p-4 border border-gray-200 rounded-lg resize-none focus:border-spa-sage focus:outline-none"
          rows={4}
        />
      </div>

      {(bookingData.addOns.length > 0 || bookingData.specialRequests) && (
        <div className="bg-spa-cream rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-spa-deep mb-3">Enhancement Summary</h4>
          
          {bookingData.addOns.length > 0 && (
            <div className="mb-3">
              <h5 className="text-sm font-semibold text-spa-deep mb-2">Selected Add-ons:</h5>
              <div className="space-y-1">
                {bookingData.addOns.map((addOn) => (
                  <div key={addOn.id} className="flex justify-between text-sm">
                    <span>{addOn.name}</span>
                    <span>+${addOn.price}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {bookingData.specialRequests && (
            <div className="mb-3">
              <h5 className="text-sm font-semibold text-spa-deep mb-2">Special Requests:</h5>
              <p className="text-sm text-spa-stone">{bookingData.specialRequests}</p>
            </div>
          )}
          
          <div className="border-t pt-3 flex justify-between font-semibold">
            <span>Total Duration: {Math.floor(bookingData.totalDuration / 60)}h {bookingData.totalDuration % 60}m</span>
            <span>Total: ${bookingData.totalPrice}</span>
          </div>
        </div>
      )}

      <div className="flex justify-between">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Therapist
        </button>
        
        <button
          onClick={onNext}
          className="px-6 py-3 rounded-full font-semibold bg-spa-gold text-white hover:bg-spa-earth transition-colors"
        >
          Review Booking
        </button>
      </div>
    </div>
  );
};

export default AddOnsSelection;