import React from 'react';
import { Clock, Plus, Minus } from 'lucide-react';
import { services } from '../../data/services';
import { BookingData, Service } from '../../types';

interface ServiceSelectionProps {
  bookingData: BookingData;
  setBookingData: (data: BookingData) => void;
  onNext: () => void;
}

const ServiceSelection: React.FC<ServiceSelectionProps> = ({
  bookingData,
  setBookingData,
  onNext,
}) => {
  const categories = [...new Set(services.map(service => service.category))];

  const isServiceSelected = (service: Service) => {
    return bookingData.services.some(s => s.id === service.id);
  };

  const toggleService = (service: Service) => {
    const isSelected = isServiceSelected(service);
    let updatedServices: Service[];
    
    if (isSelected) {
      updatedServices = bookingData.services.filter(s => s.id !== service.id);
    } else {
      updatedServices = [...bookingData.services, service];
    }

    const totalDuration = updatedServices.reduce((sum, s) => sum + s.duration, 0);
    const totalPrice = updatedServices.reduce((sum, s) => sum + s.price, 0);

    setBookingData({
      ...bookingData,
      services: updatedServices,
      totalDuration,
      totalPrice,
    });
  };

  const canProceed = bookingData.services.length > 0;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Select Your Services
        </h3>
        <p className="text-spa-stone text-sm">
          Choose one or more services for your spa experience
        </p>
      </div>

      {categories.map((category) => (
        <div key={category} className="mb-8">
          <h4 className="text-lg font-semibold text-spa-deep mb-4">{category}</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {services
              .filter(service => service.category === category)
              .map((service) => {
                const selected = isServiceSelected(service);
                return (
                  <div
                    key={service.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selected
                        ? 'border-spa-gold bg-spa-gold/10'
                        : 'border-gray-200 hover:border-spa-sage'
                    }`}
                    onClick={() => toggleService(service)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h5 className="font-semibold text-spa-deep mb-1">
                          {service.name}
                        </h5>
                        <div className="flex items-center gap-3 text-sm text-spa-stone mb-2">
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            <span>{service.duration} min</span>
                          </div>
                          <span className="font-semibold">${service.price}</span>
                        </div>
                        <p className="text-xs text-spa-stone">
                          {service.description}
                        </p>
                      </div>
                      <div className="ml-4">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            selected
                              ? 'bg-spa-gold text-white'
                              : 'bg-gray-200 text-gray-600'
                          }`}
                        >
                          {selected ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      ))}

      {bookingData.services.length > 0 && (
        <div className="bg-spa-cream rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-spa-deep mb-2">Selected Services</h4>
          <div className="space-y-2">
            {bookingData.services.map((service) => (
              <div key={service.id} className="flex justify-between text-sm">
                <span>{service.name}</span>
                <span>${service.price}</span>
              </div>
            ))}
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total Duration: {bookingData.totalDuration} min</span>
              <span>Total: ${bookingData.totalPrice}</span>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={onNext}
          disabled={!canProceed}
          className={`px-6 py-3 rounded-full font-semibold ${
            canProceed
              ? 'bg-spa-gold text-white hover:bg-spa-earth'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          } transition-colors`}
        >
          Continue to Packages
        </button>
      </div>
    </div>
  );
};

export default ServiceSelection;