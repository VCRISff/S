import React from 'react';
import Hero from '../components/Hero';
import ServicesSection from '../components/ServicesSection';
import PackagesSection from '../components/PackagesSection';

const HomePage: React.FC = () => {
  return (
    <div>
      <Hero />
      <ServicesSection />
      <PackagesSection />
    </div>
  );
};

export default HomePage;