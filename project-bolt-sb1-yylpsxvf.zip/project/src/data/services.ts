import { Service, ServicePackage, Therapist, AddOn } from '../types';

export const services: Service[] = [
  {
    id: 'swedish-massage',
    name: 'Swedish Massage',
    category: 'Massage Therapy',
    duration: 60,
    price: 120,
    description: 'A gentle, relaxing massage using long strokes and kneading techniques.',
    benefits: ['Stress relief', 'Improved circulation', 'Muscle tension release'],
    image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg'
  },
  {
    id: 'deep-tissue',
    name: 'Deep Tissue Massage',
    category: 'Massage Therapy',
    duration: 75,
    price: 150,
    description: 'Intensive massage targeting deep muscle layers and chronic tension.',
    benefits: ['Pain relief', 'Injury recovery', 'Improved mobility'],
    image: 'https://images.pexels.com/photos/3757939/pexels-photo-3757939.jpeg'
  },
  {
    id: 'hot-stone',
    name: 'Hot Stone Massage',
    category: 'Massage Therapy',
    duration: 90,
    price: 180,
    description: 'Therapeutic massage using heated stones to warm and relax muscles.',
    benefits: ['Deep relaxation', 'Enhanced circulation', 'Stress reduction'],
    image: 'https://images.pexels.com/photos/3757941/pexels-photo-3757941.jpeg'
  },
  {
    id: 'hydrafacial',
    name: 'HydraFacial',
    category: 'Facial Treatments',
    duration: 60,
    price: 200,
    description: 'Multi-step facial treatment combining cleansing, exfoliation, and hydration.',
    benefits: ['Glowing skin', 'Improved texture', 'Instant results'],
    image: 'https://images.pexels.com/photos/3985360/pexels-photo-3985360.jpeg'
  },
  {
    id: 'anti-aging-facial',
    name: 'Anti-Aging Facial',
    category: 'Facial Treatments',
    duration: 75,
    price: 250,
    description: 'Advanced facial targeting fine lines, wrinkles, and age spots.',
    benefits: ['Reduced signs of aging', 'Firmer skin', 'Enhanced radiance'],
    image: 'https://images.pexels.com/photos/3985327/pexels-photo-3985327.jpeg'
  },
  {
    id: 'body-wrap',
    name: 'Detox Body Wrap',
    category: 'Body Treatments',
    duration: 90,
    price: 160,
    description: 'Full-body treatment using natural ingredients to detoxify and nourish skin.',
    benefits: ['Skin detoxification', 'Improved skin texture', 'Relaxation'],
    image: 'https://images.pexels.com/photos/6663542/pexels-photo-6663542.jpeg'
  },
  {
    id: 'salt-scrub',
    name: 'Sea Salt Body Scrub',
    category: 'Body Treatments',
    duration: 45,
    price: 100,
    description: 'Exfoliating treatment using mineral-rich sea salt and essential oils.',
    benefits: ['Smooth skin', 'Improved circulation', 'Natural glow'],
    image: 'https://images.pexels.com/photos/6663543/pexels-photo-6663543.jpeg'
  },
  {
    id: 'hydrotherapy',
    name: 'Hydrotherapy Session',
    category: 'Hydrotherapy',
    duration: 60,
    price: 140,
    description: 'Therapeutic water-based treatment for relaxation and healing.',
    benefits: ['Muscle relaxation', 'Stress relief', 'Improved sleep'],
    image: 'https://images.pexels.com/photos/6187893/pexels-photo-6187893.jpeg'
  }
];

export const servicePackages: ServicePackage[] = [
  {
    id: 'ultimate-relaxation',
    name: 'Ultimate Relaxation Package',
    services: ['swedish-massage', 'hydrafacial', 'salt-scrub'],
    originalPrice: 420,
    packagePrice: 350,
    duration: 165,
    description: 'Complete relaxation experience combining massage, facial, and body treatment.',
    image: 'https://images.pexels.com/photos/3985327/pexels-photo-3985327.jpeg'
  },
  {
    id: 'couples-retreat',
    name: 'Couples Retreat',
    services: ['swedish-massage', 'hydrotherapy'],
    originalPrice: 520,
    packagePrice: 450,
    duration: 120,
    description: 'Romantic spa experience for two with side-by-side treatments.',
    image: 'https://images.pexels.com/photos/6663542/pexels-photo-6663542.jpeg'
  },
  {
    id: 'wellness-day',
    name: 'Full Day Wellness',
    services: ['deep-tissue', 'anti-aging-facial', 'body-wrap', 'hydrotherapy'],
    originalPrice: 740,
    packagePrice: 600,
    duration: 300,
    description: 'Complete day of rejuvenation with our most popular treatments.',
    image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg'
  }
];

export const therapists: Therapist[] = [
  {
    id: 'sarah-m',
    name: 'Sarah Martinez',
    specializations: ['Swedish Massage', 'Hot Stone', 'Aromatherapy'],
    experience: 8,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/8134842/pexels-photo-8134842.jpeg',
    bio: 'Licensed massage therapist with expertise in relaxation techniques and holistic healing.'
  },
  {
    id: 'elena-k',
    name: 'Elena Kim',
    specializations: ['Deep Tissue', 'Sports Massage', 'Injury Recovery'],
    experience: 12,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/8134841/pexels-photo-8134841.jpeg',
    bio: 'Certified therapeutic massage specialist focusing on pain relief and rehabilitation.'
  },
  {
    id: 'maya-p',
    name: 'Maya Patel',
    specializations: ['Facial Treatments', 'Anti-Aging', 'Skin Analysis'],
    experience: 10,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/8134843/pexels-photo-8134843.jpeg',
    bio: 'Licensed esthetician specializing in advanced facial treatments and skincare.'
  },
  {
    id: 'james-w',
    name: 'James Wilson',
    specializations: ['Hydrotherapy', 'Body Treatments', 'Wellness Coaching'],
    experience: 15,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/8134844/pexels-photo-8134844.jpeg',
    bio: 'Experienced wellness therapist with a focus on holistic healing and body treatments.'
  }
];

export const addOns: AddOn[] = [
  {
    id: 'aromatherapy',
    name: 'Aromatherapy Enhancement',
    price: 25,
    duration: 0,
    description: 'Custom essential oil blend for enhanced relaxation'
  },
  {
    id: 'hot-towel',
    name: 'Hot Towel Treatment',
    price: 15,
    duration: 10,
    description: 'Warm towel application for deeper muscle relaxation'
  },
  {
    id: 'scalp-massage',
    name: 'Scalp Massage',
    price: 30,
    duration: 15,
    description: 'Relaxing scalp and head massage with nourishing oils'
  },
  {
    id: 'foot-ritual',
    name: 'Reflexology Foot Ritual',
    price: 40,
    duration: 20,
    description: 'Therapeutic foot massage focusing on pressure points'
  }
];