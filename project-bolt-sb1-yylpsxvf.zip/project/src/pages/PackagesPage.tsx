import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Star, Gift } from 'lucide-react';
import { servicePackages, services } from '../data/services';

const PackagesPage: React.FC = () => {
  const getServiceName = (serviceId: string) => {
    const service = services.find(s => s.id === serviceId);
    return service ? service.name : serviceId;
  };

  return (
    <div className="min-h-screen bg-spa-cream pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            Wellness Packages
          </h1>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            Save with our specially curated packages designed for complete relaxation and rejuvenation
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {servicePackages.map((pkg, index) => (
            <div
              key={pkg.id}
              className="bg-gradient-to-br from-spa-cream to-white rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group hover:-translate-y-2 border border-spa-gold/20"
              style={{ animationDelay: `${index * 200}ms` }}
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={pkg.image}
                  alt={pkg.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-spa-deep/60 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <div className="bg-spa-gold text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                    <Gift className="w-4 h-4 mr-1" />
                    Save ${pkg.originalPrice - pkg.packagePrice}
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h2 className="text-2xl font-playfair font-bold text-white mb-2">
                    {pkg.name}
                  </h2>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4 text-spa-stone text-sm">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      <span>{Math.floor(pkg.duration / 60)}h {pkg.duration % 60}m</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 mr-1 fill-spa-gold text-spa-gold" />
                      <span>4.9</span>
                    </div>
                  </div>
                </div>

                <p className="text-spa-stone text-sm mb-4 font-inter">
                  {pkg.description}
                </p>

                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-spa-deep mb-2">Included Services:</h3>
                  <ul className="space-y-1">
                    {pkg.services.map((serviceId, idx) => (
                      <li key={idx} className="flex items-center text-xs text-spa-stone">
                        <div className="w-1.5 h-1.5 bg-spa-sage rounded-full mr-2"></div>
                        {getServiceName(serviceId)}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center justify-between mb-6">
                  <div>
                    <span className="text-sm text-spa-stone line-through">
                      ${pkg.originalPrice}
                    </span>
                    <span className="text-2xl font-bold text-spa-deep ml-2">
                      ${pkg.packagePrice}
                    </span>
                  </div>
                  <div className="text-sm text-spa-sage font-semibold">
                    {Math.round(((pkg.originalPrice - pkg.packagePrice) / pkg.originalPrice) * 100)}% OFF
                  </div>
                </div>

                <Link
                  to="/booking"
                  className="w-full bg-spa-gold text-white py-3 rounded-full font-semibold hover:bg-spa-earth transition-colors shadow-lg hover:shadow-xl block text-center"
                >
                  Book Package
                </Link>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-16">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep mb-6 text-center">
            Why Choose Our Packages?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Save Money</h3>
              <p className="text-spa-stone text-sm">
                Our packages offer significant savings compared to booking individual services
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Complete Experience</h3>
              <p className="text-spa-stone text-sm">
                Carefully curated combinations for the ultimate wellness journey
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-spa-earth rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-spa-deep mb-2">Expert Curation</h3>
              <p className="text-spa-stone text-sm">
                Designed by our wellness experts for maximum benefit and relaxation
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <Link
            to="/booking"
            className="bg-spa-gold text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spa-earth transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Book Your Package Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PackagesPage;