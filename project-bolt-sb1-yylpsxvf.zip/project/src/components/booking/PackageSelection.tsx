import React from 'react';
import { Clock, Gift, ArrowLeft } from 'lucide-react';
import { servicePackages, services } from '../../data/services';
import { BookingData, ServicePackage } from '../../types';

interface PackageSelectionProps {
  bookingData: BookingData;
  setBookingData: (data: BookingData) => void;
  onNext: () => void;
  onBack: () => void;
}

const PackageSelection: React.FC<PackageSelectionProps> = ({
  bookingData,
  setBookingData,
  onNext,
  onBack,
}) => {
  const getServiceName = (serviceId: string) => {
    const service = services.find(s => s.id === serviceId);
    return service ? service.name : serviceId;
  };

  const selectPackage = (pkg: ServicePackage) => {
    const packageServices = pkg.services.map(serviceId => 
      services.find(s => s.id === serviceId)!
    ).filter(Boolean);

    setBookingData({
      ...bookingData,
      services: packageServices,
      packages: [pkg],
      totalDuration: pkg.duration,
      totalPrice: pkg.packagePrice,
    });
  };

  const skipPackages = () => {
    setBookingData({
      ...bookingData,
      packages: [],
    });
    onNext();
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Consider Our Packages
        </h3>
        <p className="text-spa-stone text-sm">
          Save money by choosing one of our curated wellness packages, or skip to continue with individual services
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {servicePackages.map((pkg) => (
          <div
            key={pkg.id}
            className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => selectPackage(pkg)}
          >
            <div className="relative h-32">
              <img
                src={pkg.image}
                alt={pkg.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2">
                <div className="bg-spa-gold text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center">
                  <Gift className="w-3 h-3 mr-1" />
                  Save ${pkg.originalPrice - pkg.packagePrice}
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <h4 className="font-semibold text-spa-deep mb-2">{pkg.name}</h4>
              
              <div className="flex items-center gap-2 text-sm text-spa-stone mb-2">
                <Clock className="w-4 h-4" />
                <span>{Math.floor(pkg.duration / 60)}h {pkg.duration % 60}m</span>
              </div>
              
              <p className="text-xs text-spa-stone mb-3">{pkg.description}</p>
              
              <div className="mb-3">
                <h5 className="text-xs font-semibold text-spa-deep mb-1">Includes:</h5>
                <ul className="space-y-1">
                  {pkg.services.map((serviceId, idx) => (
                    <li key={idx} className="text-xs text-spa-stone flex items-center">
                      <div className="w-1 h-1 bg-spa-sage rounded-full mr-2"></div>
                      {getServiceName(serviceId)}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-spa-stone line-through">
                    ${pkg.originalPrice}
                  </span>
                  <span className="text-lg font-bold text-spa-deep ml-2">
                    ${pkg.packagePrice}
                  </span>
                </div>
                <span className="text-xs text-spa-sage font-semibold">
                  {Math.round(((pkg.originalPrice - pkg.packagePrice) / pkg.originalPrice) * 100)}% OFF
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-spa-cream rounded-lg p-4 mb-6">
        <h4 className="font-semibold text-spa-deep mb-2">Current Selection</h4>
        <div className="space-y-2">
          {bookingData.services.map((service) => (
            <div key={service.id} className="flex justify-between text-sm">
              <span>{service.name}</span>
              <span>${service.price}</span>
            </div>
          ))}
          <div className="border-t pt-2 flex justify-between font-semibold">
            <span>Total Duration: {bookingData.totalDuration} min</span>
            <span>Total: ${bookingData.totalPrice}</span>
          </div>
        </div>
      </div>

      <div className="flex justify-between">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Services
        </button>
        <button
          onClick={skipPackages}
          className="px-6 py-3 rounded-full font-semibold bg-spa-gold text-white hover:bg-spa-earth transition-colors"
        >
          Continue with Individual Services
        </button>
      </div>
    </div>
  );
};

export default PackageSelection;