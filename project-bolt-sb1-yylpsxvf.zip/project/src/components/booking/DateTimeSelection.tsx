import React, { useState } from 'react';
import { Calendar, Clock, ArrowLeft } from 'lucide-react';
import { format, addDays, isSameDay, isAfter, startOfDay } from 'date-fns';
import { BookingData, TimeSlot } from '../../types';

interface DateTimeSelectionProps {
  bookingData: BookingData;
  setBookingData: (data: BookingData) => void;
  onNext: () => void;
  onBack: () => void;
}

const DateTimeSelection: React.FC<DateTimeSelectionProps> = ({
  bookingData,
  setBookingData,
  onNext,
  onBack,
}) => {
  const [selectedDate, setSelectedDate] = useState<Date | null>(bookingData.selectedDate);

  // Generate next 30 days
  const availableDates = Array.from({ length: 30 }, (_, i) => addDays(new Date(), i));
  
  // Mock time slots (in a real app, this would come from the API)
  const generateTimeSlots = (date: Date): TimeSlot[] => {
    const slots: TimeSlot[] = [];
    const times = [
      '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
      '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM',
      '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM',
      '6:00 PM', '6:30 PM', '7:00 PM'
    ];

    times.forEach(time => {
      // Randomly make some slots unavailable for demo purposes
      const available = Math.random() > 0.3;
      slots.push({ time, available });
    });

    return slots;
  };

  const timeSlots = selectedDate ? generateTimeSlots(selectedDate) : [];

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setBookingData({
      ...bookingData,
      selectedDate: date,
      selectedTime: '', // Reset selected time when date changes
    });
  };

  const handleTimeSelect = (time: string) => {
    setBookingData({
      ...bookingData,
      selectedTime: time,
    });
  };

  const canProceed = selectedDate && bookingData.selectedTime;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Select Date & Time
        </h3>
        <p className="text-spa-stone text-sm">
          Choose your preferred date and time for your spa experience
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Date Selection */}
        <div>
          <h4 className="flex items-center text-lg font-semibold text-spa-deep mb-4">
            <Calendar className="w-5 h-5 mr-2" />
            Select Date
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-80 overflow-y-auto">
            {availableDates.map((date) => {
              const isSelected = selectedDate && isSameDay(date, selectedDate);
              const isToday = isSameDay(date, new Date());
              
              return (
                <button
                  key={date.toISOString()}
                  onClick={() => handleDateSelect(date)}
                  className={`p-3 rounded-lg text-center transition-colors ${
                    isSelected
                      ? 'bg-spa-gold text-white'
                      : 'bg-gray-50 hover:bg-spa-cream text-spa-deep'
                  }`}
                >
                  <div className="text-xs text-current opacity-75">
                    {format(date, 'EEE')}
                  </div>
                  <div className="text-lg font-semibold">
                    {format(date, 'd')}
                  </div>
                  <div className="text-xs text-current opacity-75">
                    {format(date, 'MMM')}
                  </div>
                  {isToday && (
                    <div className="text-xs mt-1 font-semibold">Today</div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Time Selection */}
        <div>
          <h4 className="flex items-center text-lg font-semibold text-spa-deep mb-4">
            <Clock className="w-5 h-5 mr-2" />
            Select Time
            {selectedDate && (
              <span className="ml-2 text-sm font-normal text-spa-stone">
                {format(selectedDate, 'MMMM d, yyyy')}
              </span>
            )}
          </h4>
          
          {!selectedDate ? (
            <p className="text-spa-stone text-sm">Please select a date first</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-80 overflow-y-auto">
              {timeSlots.map((slot) => {
                const isSelected = bookingData.selectedTime === slot.time;
                
                return (
                  <button
                    key={slot.time}
                    onClick={() => slot.available && handleTimeSelect(slot.time)}
                    disabled={!slot.available}
                    className={`p-3 rounded-lg text-center transition-colors ${
                      !slot.available
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : isSelected
                        ? 'bg-spa-gold text-white'
                        : 'bg-gray-50 hover:bg-spa-cream text-spa-deep'
                    }`}
                  >
                    {slot.time}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {selectedDate && bookingData.selectedTime && (
        <div className="bg-spa-cream rounded-lg p-4 mt-6">
          <h4 className="font-semibold text-spa-deep mb-2">Selected Appointment</h4>
          <p className="text-spa-stone">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')} at {bookingData.selectedTime}
          </p>
          <p className="text-sm text-spa-stone mt-1">
            Duration: {Math.floor(bookingData.totalDuration / 60)}h {bookingData.totalDuration % 60}m
          </p>
        </div>
      )}

      <div className="flex justify-between mt-8">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Packages
        </button>
        <button
          onClick={onNext}
          disabled={!canProceed}
          className={`px-6 py-3 rounded-full font-semibold ${
            canProceed
              ? 'bg-spa-gold text-white hover:bg-spa-earth'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          } transition-colors`}
        >
          Select Therapist
        </button>
      </div>
    </div>
  );
};

export default DateTimeSelection;