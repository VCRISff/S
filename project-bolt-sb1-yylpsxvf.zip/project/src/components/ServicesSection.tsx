import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Star } from 'lucide-react';
import { services } from '../data/services';

const ServicesSection: React.FC = () => {
  const categories = [...new Set(services.map(service => service.category))];
  const featuredServices = services.slice(0, 6); // Show first 6 services on homepage

  return (
    <section id="services" className="py-20 bg-spa-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            Our Premium Services
          </h2>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            Indulge in our carefully curated selection of treatments designed to restore balance and enhance well-being
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredServices.map((service, index) => (
            <div
              key={service.id}
              className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group hover:-translate-y-2"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-spa-gold text-white px-3 py-1 rounded-full text-sm font-semibold">
                  ${service.price}
                </div>
              </div>
              
              <div className="p-6">
                <h4 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
                  {service.name}
                </h4>
                
                <div className="flex items-center gap-4 mb-3 text-spa-stone text-sm">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{service.duration} min</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 mr-1 fill-spa-gold text-spa-gold" />
                    <span>4.9</span>
                  </div>
                </div>
                
                <p className="text-spa-stone text-sm mb-4 font-inter">
                  {service.description}
                </p>
                
                <div className="mb-4">
                  <h5 className="text-sm font-semibold text-spa-deep mb-2">Benefits:</h5>
                  <ul className="text-xs text-spa-stone space-y-1">
                    {service.benefits.slice(0, 3).map((benefit, idx) => (
                      <li key={idx} className="flex items-center">
                        <div className="w-1.5 h-1.5 bg-spa-sage rounded-full mr-2"></div>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <Link
                  to="/booking"
                  className="w-full bg-spa-sage text-white py-3 rounded-full font-semibold hover:bg-spa-deep transition-colors block text-center"
                >
                  Book This Service
                </Link>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/services"
            className="bg-spa-gold text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-spa-earth transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            View All Services
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;