import React from 'react';
import { Star, Award, ArrowLeft } from 'lucide-react';
import { therapists } from '../../data/services';
import { BookingData, Therapist } from '../../types';

interface TherapistSelectionProps {
  bookingData: BookingData;
  setBookingData: (data: BookingData) => void;
  onNext: () => void;
  onBack: () => void;
}

const TherapistSelection: React.FC<TherapistSelectionProps> = ({
  bookingData,
  setBookingData,
  onNext,
  onBack,
}) => {
  const handleTherapistSelect = (therapist: Therapist) => {
    setBookingData({
      ...bookingData,
      selectedTherapist: therapist,
    });
  };

  const skipTherapistSelection = () => {
    setBookingData({
      ...bookingData,
      selectedTherapist: null,
    });
    onNext();
  };

  // Filter therapists based on selected services
  const relevantTherapists = therapists.filter(therapist => {
    const serviceCategories = bookingData.services.map(s => s.category);
    return therapist.specializations.some(spec => 
      serviceCategories.some(cat => cat.includes(spec.split(' ')[0]))
    );
  });

  const displayTherapists = relevantTherapists.length > 0 ? relevantTherapists : therapists;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h3 className="text-xl font-playfair font-semibold text-spa-deep mb-2">
          Choose Your Therapist
        </h3>
        <p className="text-spa-stone text-sm">
          Select a preferred therapist or let us assign the best available professional for your services
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {displayTherapists.map((therapist) => {
          const isSelected = bookingData.selectedTherapist?.id === therapist.id;
          
          return (
            <div
              key={therapist.id}
              className={`border rounded-lg p-6 cursor-pointer transition-all ${
                isSelected
                  ? 'border-spa-gold bg-spa-gold/10'
                  : 'border-gray-200 hover:border-spa-sage hover:shadow-md'
              }`}
              onClick={() => handleTherapistSelect(therapist)}
            >
              <div className="flex items-start space-x-4">
                <div className="relative">
                  <img
                    src={therapist.image}
                    alt={therapist.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-spa-gold text-white rounded-full flex items-center justify-center">
                      <Award className="w-3 h-3" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1">
                  <h4 className="font-semibold text-spa-deep mb-1">
                    {therapist.name}
                  </h4>
                  
                  <div className="flex items-center mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(therapist.rating)
                              ? 'text-spa-gold fill-spa-gold'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-spa-stone">
                      {therapist.rating} ({therapist.experience} years)
                    </span>
                  </div>
                  
                  <div className="mb-3">
                    <h5 className="text-xs font-semibold text-spa-deep mb-1">
                      Specializations:
                    </h5>
                    <div className="flex flex-wrap gap-1">
                      {therapist.specializations.map((spec, idx) => (
                        <span
                          key={idx}
                          className="text-xs bg-spa-sage/20 text-spa-sage px-2 py-1 rounded-full"
                        >
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <p className="text-xs text-spa-stone">{therapist.bio}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {bookingData.selectedTherapist && (
        <div className="bg-spa-cream rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-spa-deep mb-2">Selected Therapist</h4>
          <div className="flex items-center space-x-3">
            <img
              src={bookingData.selectedTherapist.image}
              alt={bookingData.selectedTherapist.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold text-spa-deep">
                {bookingData.selectedTherapist.name}
              </p>
              <p className="text-sm text-spa-stone">
                {bookingData.selectedTherapist.experience} years experience • 
                {bookingData.selectedTherapist.rating} ⭐
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between">
        <button
          onClick={onBack}
          className="flex items-center px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Date & Time
        </button>
        
        <div className="space-x-3">
          <button
            onClick={skipTherapistSelection}
            className="px-6 py-3 text-spa-stone hover:text-spa-deep transition-colors"
          >
            No Preference
          </button>
          <button
            onClick={onNext}
            className="px-6 py-3 rounded-full font-semibold bg-spa-gold text-white hover:bg-spa-earth transition-colors"
          >
            Continue to Add-ons
          </button>
        </div>
      </div>
    </div>
  );
};

export default TherapistSelection;