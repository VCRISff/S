import React, { useState } from 'react';
import { Gift, Heart, Star, CreditCard } from 'lucide-react';

const GiftCardsPage: React.FC = () => {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [giftCardData, setGiftCardData] = useState({
    recipientName: '',
    recipientEmail: '',
    senderName: '',
    message: '',
    deliveryDate: ''
  });

  const predefinedAmounts = [50, 100, 150, 200, 300, 500];

  const handleInputChange = (field: string, value: string) => {
    setGiftCardData(prev => ({ ...prev, [field]: value }));
  };

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmount = (value: string) => {
    setCustomAmount(value);
    setSelectedAmount(null);
  };

  const getFinalAmount = () => {
    return selectedAmount || parseInt(customAmount) || 0;
  };

  return (
    <div className="min-h-screen bg-spa-cream pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-spa-deep mb-6">
            Gift Cards
          </h1>
          <p className="text-lg text-spa-stone max-w-3xl mx-auto font-inter">
            Give the gift of wellness and relaxation. Perfect for any occasion.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Gift Card Preview */}
          <div className="space-y-8">
            <div className="bg-gradient-to-br from-spa-gold to-spa-earth rounded-2xl shadow-2xl p-8 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-playfair font-bold">Healing Days</h2>
                    <p className="text-spa-cream text-sm">Luxury Spa Experience</p>
                  </div>
                  <Gift className="w-8 h-8" />
                </div>
                
                <div className="mb-6">
                  <p className="text-spa-cream text-sm mb-2">Gift Card Value</p>
                  <p className="text-4xl font-bold">
                    ${getFinalAmount() || '---'}
                  </p>
                </div>
                
                <div className="mb-6">
                  <p className="text-spa-cream text-sm mb-1">To:</p>
                  <p className="text-lg font-semibold">
                    {giftCardData.recipientName || 'Recipient Name'}
                  </p>
                </div>
                
                <div className="mb-6">
                  <p className="text-spa-cream text-sm mb-1">From:</p>
                  <p className="font-semibold">
                    {giftCardData.senderName || 'Your Name'}
                  </p>
                </div>
                
                {giftCardData.message && (
                  <div className="bg-white/10 rounded-lg p-4">
                    <p className="text-sm italic">"{giftCardData.message}"</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-xl font-playfair font-bold text-spa-deep mb-4">
                Why Choose Our Gift Cards?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Heart className="w-5 h-5 text-spa-gold mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-spa-deep">Perfect for Any Occasion</h4>
                    <p className="text-spa-stone text-sm">Birthdays, anniversaries, holidays, or just because</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Star className="w-5 h-5 text-spa-gold mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-spa-deep">Flexible Usage</h4>
                    <p className="text-spa-stone text-sm">Can be used for any service or package</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CreditCard className="w-5 h-5 text-spa-gold mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-spa-deep">Never Expires</h4>
                    <p className="text-spa-stone text-sm">No expiration date or hidden fees</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Gift Card Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-playfair font-bold text-spa-deep mb-6">
              Create Your Gift Card
            </h2>

            <form className="space-y-6">
              {/* Amount Selection */}
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-3">
                  Select Amount
                </label>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  {predefinedAmounts.map((amount) => (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => handleAmountSelect(amount)}
                      className={`p-3 rounded-lg border-2 transition-colors ${
                        selectedAmount === amount
                          ? 'border-spa-gold bg-spa-gold text-white'
                          : 'border-gray-200 hover:border-spa-sage'
                      }`}
                    >
                      ${amount}
                    </button>
                  ))}
                </div>
                <div>
                  <label className="block text-xs text-spa-stone mb-2">
                    Or enter custom amount
                  </label>
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => handleCustomAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    min="25"
                  />
                </div>
              </div>

              {/* Recipient Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Recipient Name *
                  </label>
                  <input
                    type="text"
                    value={giftCardData.recipientName}
                    onChange={(e) => handleInputChange('recipientName', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-spa-deep mb-2">
                    Recipient Email *
                  </label>
                  <input
                    type="email"
                    value={giftCardData.recipientEmail}
                    onChange={(e) => handleInputChange('recipientEmail', e.target.value)}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                    required
                  />
                </div>
              </div>

              {/* Sender Information */}
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  Your Name *
                </label>
                <input
                  type="text"
                  value={giftCardData.senderName}
                  onChange={(e) => handleInputChange('senderName', e.target.value)}
                  className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                  required
                />
              </div>

              {/* Personal Message */}
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  Personal Message (Optional)
                </label>
                <textarea
                  value={giftCardData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  rows={4}
                  className="w-full p-3 border border-gray-200 rounded-lg resize-none focus:border-spa-sage focus:outline-none"
                  placeholder="Add a personal message..."
                  maxLength={200}
                />
                <p className="text-xs text-spa-stone mt-1">
                  {giftCardData.message.length}/200 characters
                </p>
              </div>

              {/* Delivery Date */}
              <div>
                <label className="block text-sm font-semibold text-spa-deep mb-2">
                  Delivery Date (Optional)
                </label>
                <input
                  type="date"
                  value={giftCardData.deliveryDate}
                  onChange={(e) => handleInputChange('deliveryDate', e.target.value)}
                  className="w-full p-3 border border-gray-200 rounded-lg focus:border-spa-sage focus:outline-none"
                  min={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-spa-stone mt-1">
                  Leave blank to send immediately
                </p>
              </div>

              {/* Total */}
              <div className="bg-spa-cream rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-spa-deep">Total:</span>
                  <span className="text-2xl font-bold text-spa-deep">
                    ${getFinalAmount() || '0'}
                  </span>
                </div>
              </div>

              {/* Purchase Button */}
              <button
                type="submit"
                disabled={!getFinalAmount() || !giftCardData.recipientName || !giftCardData.recipientEmail || !giftCardData.senderName}
                className={`w-full py-4 rounded-full font-semibold transition-colors ${
                  getFinalAmount() && giftCardData.recipientName && giftCardData.recipientEmail && giftCardData.senderName
                    ? 'bg-spa-gold text-white hover:bg-spa-earth shadow-lg hover:shadow-xl'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Purchase Gift Card
              </button>
            </form>
          </div>
        </div>

        {/* Popular Gift Card Packages */}
        <div className="mt-20">
          <h2 className="text-3xl font-playfair font-bold text-spa-deep text-center mb-12">
            Popular Gift Card Packages
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-6 text-center">
              <div className="w-16 h-16 bg-spa-sage rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-spa-deep mb-2">Relaxation Starter</h3>
              <p className="text-3xl font-bold text-spa-gold mb-2">$150</p>
              <p className="text-spa-stone text-sm mb-4">
                Perfect for a massage or facial treatment
              </p>
              <button
                onClick={() => handleAmountSelect(150)}
                className="w-full bg-spa-sage text-white py-2 rounded-full font-semibold hover:bg-spa-deep transition-colors"
              >
                Select This Package
              </button>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6 text-center border-2 border-spa-gold">
              <div className="w-16 h-16 bg-spa-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-spa-deep mb-2">Luxury Experience</h3>
              <p className="text-3xl font-bold text-spa-gold mb-2">$300</p>
              <p className="text-spa-stone text-sm mb-4">
                Ideal for our premium packages and treatments
              </p>
              <button
                onClick={() => handleAmountSelect(300)}
                className="w-full bg-spa-gold text-white py-2 rounded-full font-semibold hover:bg-spa-earth transition-colors"
              >
                Select This Package
              </button>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6 text-center">
              <div className="w-16 h-16 bg-spa-earth rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-spa-deep mb-2">Ultimate Indulgence</h3>
              <p className="text-3xl font-bold text-spa-gold mb-2">$500</p>
              <p className="text-spa-stone text-sm mb-4">
                For the complete spa day experience
              </p>
              <button
                onClick={() => handleAmountSelect(500)}
                className="w-full bg-spa-earth text-white py-2 rounded-full font-semibold hover:bg-spa-deep transition-colors"
              >
                Select This Package
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GiftCardsPage;